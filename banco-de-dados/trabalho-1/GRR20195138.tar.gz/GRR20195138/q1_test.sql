select distinct(r_name) 
from REGION
;